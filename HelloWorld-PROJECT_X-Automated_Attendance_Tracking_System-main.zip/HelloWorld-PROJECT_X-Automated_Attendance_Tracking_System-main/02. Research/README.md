# Design
This folder includes system design documents, wireframes, and architecture diagrams.