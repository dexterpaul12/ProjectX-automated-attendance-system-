# Hello World! - PROJECT X: Automated Attendance Tracking System
 Automated Attendance Tracking System
