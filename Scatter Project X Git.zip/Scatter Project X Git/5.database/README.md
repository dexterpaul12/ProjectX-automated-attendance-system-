# Database
Stores database schemas, SQL scripts, and ER diagrams related to the project.
