# Requirements
This folder contains all project requirement documents, including system specifications, use case diagrams, and other related documentation.